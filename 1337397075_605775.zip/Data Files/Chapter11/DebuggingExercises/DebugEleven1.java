// Instantiates Rowboat
// Rowboat is child of Boat
public class DebugEleven1
{
   public static void main(String[] args)
   {
      DebugRowboat myBoat = DebugRowboat();
      System.out.println(myBoat());
   }
}
