public class DebugOceanLiner extends DebugBoat
{
   public DebugOceanLiner()
   {
      super("ocean liner ");
      setPassengers();
  }
   public void setPassengers()
   {
      super.passengers = 2400;
   }
   public void setPower()
   {
      superpower = "four engines";
   }
}
