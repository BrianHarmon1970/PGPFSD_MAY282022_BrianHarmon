public interface Worker
{
   public abstract void work();
}