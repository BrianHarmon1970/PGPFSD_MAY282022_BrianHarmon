public class Snake extends Animal
{
   @Override
   public void speak()
   {
      System.out.println("Ssss!");
   }
}
