public class ErrorTest
/*  This class displays a test message 
{
   public static void main(String[] args)
   {
      System.out.println("Test");
   }
}
