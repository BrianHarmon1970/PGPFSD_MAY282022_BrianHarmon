import javax.swing.JOptionPane;
public class AreaCodeDialog
{
   public static void main(String[] args)
   {
      JOptionPane.showInputDialog(null, 
         "What is your area code?",
         "Area code information",
         JOptionPane.QUESTION_MESSAGE);
   }
}
