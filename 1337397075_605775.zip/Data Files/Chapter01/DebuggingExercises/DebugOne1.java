public class DebugOne1
{
   /* This program displays a greeting
   public void main(String[] args)
   {
      System.out.println("Hello")
   }
}