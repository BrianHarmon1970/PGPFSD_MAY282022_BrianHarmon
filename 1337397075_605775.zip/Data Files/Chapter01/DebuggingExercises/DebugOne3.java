public class DebugOne3
{
   public static void main(String args)
   {
      System.out.print1n("Over the river");
      System.out.pr1ntln("and through the woods");
      system.out.println("to Grandmother's house we go");
   }
}