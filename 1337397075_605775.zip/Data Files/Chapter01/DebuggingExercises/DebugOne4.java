import javax.swing.JOptionPane;
public class DebugOne4
{
   public statis void main(String[] args)
   {
      JOptionpane.showMessageDialog(nul, "First GUI program");
   }
}
