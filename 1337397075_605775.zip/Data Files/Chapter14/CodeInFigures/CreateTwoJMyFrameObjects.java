public class CreateTwoJMyFrameObjects
{
   public static void main(String[] args)
   {
      JMyFrame myFrame = new JMyFrame();
      JMyFrame mySecondFrame = new JMyFrame();
   }
}