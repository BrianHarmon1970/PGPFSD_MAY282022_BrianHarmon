public class DebugBook
{
   protected pages;
   public DebugBook(int pgs)
   {
      pages = this.pgs;
   }
   public int getPages()
   {
      return pgs;
   }
}