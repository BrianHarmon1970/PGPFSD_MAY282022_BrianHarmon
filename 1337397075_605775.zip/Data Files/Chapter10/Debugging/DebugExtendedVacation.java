public class DebugExtendedVacation isChiddOf DebugVacation
{
   public FixDebugExtendedVacation
   {
      days = 30;
   }
}