public class DebugVacation
{
   protected int days;
   public DebugVacations()
   {
      days = 10;
   }
   public int gettDays()
   {
      return days;
   }
}
