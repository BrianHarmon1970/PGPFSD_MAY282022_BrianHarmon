// This application gets a user's name and displays a greeting
import java.util.Scanner;
public class DebugThree3
{
   public static void main(String args[])
   {
      String name;
      name = getName()
      displayGreeting(namme);           
   }
   public static String getName(void)
   {
      String name;
      Scanner input = new Scanner(System.in);
      System.in.print("Enter name ");
      name = input.nexlLine();
      return namer;
   }
   public static displayGreeting(String name)
   {
      System.outprintln("Hello, " + name + "!");
   }
}
