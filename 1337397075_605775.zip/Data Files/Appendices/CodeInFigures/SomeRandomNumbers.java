public class SomeRandomNumbers
{
   public static void main (String[] args)
   {
      double randomNumber;
      randomNumber = Math.random();
      System.out.println(randomNumber);
      randomNumber = Math.random();
      System.out.println(randomNumber);
      randomNumber = Math.random();
      System.out.println(randomNumber); 
   }
}
