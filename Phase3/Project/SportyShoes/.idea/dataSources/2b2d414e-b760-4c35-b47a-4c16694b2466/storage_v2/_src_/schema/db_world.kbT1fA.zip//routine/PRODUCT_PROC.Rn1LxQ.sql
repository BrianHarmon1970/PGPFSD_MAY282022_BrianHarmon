create
    definer = root@localhost procedure PRODUCT_PROC(IN pid int, OUT pname varchar(50), INOUT pprice decimal(10, 2))
BEGIN
declare tempPrice decimal(10,2);    
-- Select data
select name,price into pname,tempPrice from product where id = pid;    
-- Update new price
update product set price=pprice where  id = pid;  
-- Return old price
set pprice= tempPrice;    
END;

