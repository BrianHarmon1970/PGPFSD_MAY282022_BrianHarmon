create
    definer = root@localhost procedure update_price(IN temp_ISBN varchar(10), IN new_price int)
begin
update book set price=new_price where ISBN=temp_ISBN;
end;

