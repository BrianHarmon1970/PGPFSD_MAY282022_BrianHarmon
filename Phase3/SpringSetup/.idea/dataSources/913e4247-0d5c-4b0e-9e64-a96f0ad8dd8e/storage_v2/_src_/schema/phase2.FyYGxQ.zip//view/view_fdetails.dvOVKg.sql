create definer = root@localhost view view_fdetails as
select `fd`.`ID`              AS `ID`,
       `dc`.`city_name`       AS `departure_city`,
       `ac`.`city_name`       AS `arrival_city`,
       `a`.`airline_name`     AS `airline`,
       `fd`.`available_seats` AS `available_seats`,
       `fd`.`travel_date`     AS `travel_date`,
       `a`.`ticket_price`     AS `ticket_price`
from `phase2`.`flight_detail` `fd`
         join `phase2`.`city` `dc`
         join `phase2`.`city` `ac`
         join `phase2`.`airline` `a`
where ((`fd`.`departure_cityID` = `dc`.`ID`) and (`fd`.`arrival_cityID` = `ac`.`ID`) and (`fd`.`airlineID` = `a`.`ID`));

