package com.example.dockerspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
